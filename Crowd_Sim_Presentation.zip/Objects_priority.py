from bge import logic
import random
import math

def slowtostop(my, slowlimit):
	
	if my > slowlimit + 0.00001:
		my *= 0.5
	elif my <= slowlimit + 0.00001:
		my = slowlimit
	
	#print(my, slowlimit)
	return my

def accelerate(my, speed):
	
	if my == 0:
		my = 0.00005
	if my < speed:
		my += 0.00005
	if my >= speed:
		my = speed
	return my

def choosedirection(chkright, chkleft, turn_dir, vec):
	if chkleft == 0 and chkright == 1: #and turn_dir != 2:
		turn_dir = 1			#turn left
		#print('left')
	elif chkleft == 1 and chkright == 0: #and turn_dir != 1:
		turn_dir = 2			#turn right
		#print('right')
	elif chkleft == chkright:	#turn in the direction of the track to target
		if vec[2].x < 0:
			turn_dir = 1
		else:
			turn_dir = 2
		#print('vector')
	#elif chkleft == 1 and chkright == 1:
	#	turn_dir = random.choice([1,2])	
	#	print('random')
	return turn_dir	

def wallprop(enemy):
	if 'wall' in enemy:
		wall = True
	else:
		wall = False
	return wall


def Player():
	
		
	cont = logic.getCurrentController()
	scene = logic.getCurrentScene()
	obj = cont.owner
	motion = cont.actuators['Motion']
	rad_near = cont.sensors["radar_front_near"]
	rad_distance = cont.sensors["radar_front_distance"]
	radar_left = cont.sensors['radar_left']
	radar_right = cont.sensors['radar_right']
	radar_right = cont.sensors['radar_right']
	ray_wall = cont.sensors['Ray_wall']
	ray_ground = cont.sensors['Ray_Ground']
	trigger = cont.sensors['near_trigger']
	#radar_ground = cont.sensors['radar_ground']
	track_to = cont.actuators["Track_to"]
	attach = cont.actuators["attach"]
	speed = obj['speed']
	turnlimit = 0.04
	turnaccel = 0.004
	
					
	def Update():
		stop = False
		slowlimit = 0
		turn_y = 0
		target = track_to.object
		target_dist = obj.getDistanceTo(target)
		vec = obj.getVectTo(target.position)
		old_dir = obj['turn_dir']
		old_climb = obj['climb']
		enemy = None
		wall = False
		dist = 0
		chkright = radar_right.positive
		chkleft = radar_left.positive
		if chkright == 1 and chkleft == 1:
			available = False
		else:
			available = True
		angle_y = 0
		angle_x = 0
		angle_z = 0
		rot = obj.worldOrientation
		rot_x = obj.localOrientation.to_euler().x
		rot_y = obj.localOrientation.to_euler().y
		rot_z = obj.localOrientation.to_euler().z
		#print(rot_x, rot_y, rot_z)
		
		#create an array of targets
		path = []
		pathflip = []
		for node in scene.objects:
			if obj['target'] in node.name: 
				pathflip.append(node)
		
		#reversing the path order for the correct order, if started
		if obj['pathDir'] == False:
			for node in reversed(pathflip):
				path.append(node)
		#when finish the path go backward	
		else:
			for node in pathflip:
				path.append(node)
			
		#select next target when reaching it	
		if 0 <= obj['point'] < len(path):
			if target_dist <= 0.06: 
				if obj['pathDir'] == False:
					obj['point'] += 1
				elif obj['pathDir'] == True:
					obj['point'] -= 1
				
		
		
		#when path is finished go backward through the pass
		if obj['point'] >= len(path): 
			obj['pathDir'] = True
			obj['point'] -= 1			
		#	print(obj['pathDir'])
		#	

		if obj['point'] == 0:
			obj['pathDir'] = False
			#obj['point'] += 1
		point = obj['point']
		target = path[point]
		track_to.object = target
		
		
		#checking for nearby objects
		if rad_near.hitObject != None:
			
			enemy = rad_near.hitObject
			wall = wallprop(enemy)
			
			
			if wall == False:
				stop = True
				slowlimit = 0
				enemy_rot_x = enemy.localOrientation.to_euler().x
				rot_difference = enemy_rot_x - rot_x
				
			else:
				slowlimit =  0.00001

			if obj['turn_dir'] == 0 and wall == False:
				#obj['turn_dir'] = choosedirection(chkright, chkleft, obj['turn_dir'], vec)

				#if object priority is small then enemy, or because one is climbing and the other just before climb then stops <-- cancelled
				if obj['priority'] < enemy['priority'] or rot_difference > 1 or rot_difference < -1:
				
				#if enemy.getDistanceTo(target) < obj.getDistanceTo(target) and 'speed' in enemy or rot_difference > 1 or rot_difference < -1:					
					
					slowlimit = 0
					if obj['my'] != 0:
						obj['timer'] = 0	
					elif obj['my'] == 0 and obj['timer'] < 2:
						stop = True
	
					elif obj['timer'] > 2:		#if he stops for more then 1 second he need to turn
						obj['turn_dir'] = choosedirection(chkright, chkleft, obj['turn_dir'], vec)
						obj['timer'] = 0	#reset timer before starts to turn
						stop = False
							
				else:			#go directly into turning mode	
					#dist = enemy.getDistanceTo(obj)
					#slowlimit = 0				
					obj['turn_dir'] = choosedirection(chkright, chkleft, obj['turn_dir'], vec)
				

					

		if rad_near.hitObject == None and stop == True and obj['timer'] > 1: 	#if enemy is gone then continue
			stop = False
		#	print('continue', obj)
		
		#checking for distance objects

		if rad_distance.hitObject != None and stop == False and rad_near.hitObject == None:
			enemy = rad_distance.hitObject
			wall = wallprop(enemy)
			dist = enemy.getDistanceTo(obj)			#apply distance for slowing down by distance
			if rad_near.distance < dist <= rad_distance.distance and obj['timer'] > 0.4 and obj['my'] > 0.002: 
				slowlimit = speed*(dist/rad_distance.distance)	#slowing down by distance
				stop = True	
			
			if obj['priority'] < enemy['priority'] and obj['turn_dir'] == 0 and 'speed' in enemy and obj['my'] > 0 and obj['timer'] > 0.5:
			#if enemy.getDistanceTo(target) > obj.getDistanceTo(target) and obj['my'] > 0 and 'speed' in enemy:
				if obj['turn_dir'] == 0:
					obj['turn_dir'] = choosedirection(chkright, chkleft, obj['turn_dir'], vec)		
			else:
				obj['turn_dir'] = 0
				
		
		#if there is nothing continue moving forward speeding up
		elif rad_distance.hitObject == None and rad_near.hitObject == None and obj['climb'] == 0: 
			enemy = None
			obj['turn_dir'] = 0
			stop = False
	

		#checking for climbing
		climbchk = ray_wall.hitObject
		if climbchk != None and climbchk['priority'] < obj['priority']:# and obj['climb'] == 0:
			
			hit = ray_wall.hitNormal
			angle_y = math.degrees(rot[0].angle(hit))
			slowlimit =  0.001
			stop = True
			#Make cube parallel to wall before start climbing
			if angle_y < 85 and obj['climb'] == 0:
				obj['turn_dir'] = 1		#going left
				#turnlimit = 0.05

				
						
			elif angle_y > 95 and obj['climb'] == 0:
				obj['turn_dir'] = 2		#going left
				#turnlimit = 0.05
				
				
			else:
				obj['climb'] = 1	#climb up
				
				#obj['speed'] = 0.003
				obj['turn_dir'] = 0	#stop rotation
				obj['turn_Z'] = 0

		#climb down
		elif ray_ground.hitObject == None and rad_near.hitObject == None and obj['turn_dir'] == 0:# and obj['climb'] == 0:
			obj['climb'] = 2	
			slowlimit = 0.0005
			stop = True
			

		# make sure parallel to ground before continue going
		
		elif ray_ground.hitObject != None:
			ground = ray_ground.hitObject
			
			#function stop cockroach from climbing on other roaches - cancelled
			#if 'speed' in ground:
			#	obj['climb'] = 0
			#	slowlimit = 0
			#	stop = True
				
			#else:
			
			hit = ray_ground.hitNormal
			angle_z = math.degrees(rot[2].angle(hit))
			angle_y = math.degrees(rot[1].angle(hit))
			angle_x = math.degrees(rot[0].angle(hit))
			
			if 15 < angle_z < 45 and obj['climb'] != 0:
				slowlimit = 0.0005
				stop = True
				cont.activate(attach)
			if 70 > angle_z > 5 and obj['climb'] == 1 and obj['timer'] > 0.3 and climbchk == None:
				obj['climb'] = 0
			elif 0 < angle_z < 15 and obj['climb'] == 2 and obj['timer'] > 0.1:
				obj['climb'] = 0
				
			#make sure he don't 'over climb'
			if angle_y == 90 and obj['climb'] == 2:
				obj['climb'] = 0
			elif angle_y > 90 and obj['climb'] == 2:
				obj['climb'] = 1
				
				#keep parallel also on the sides
			if angle_x < 87:
				turn_y += 0.02
			elif angle_x > 93:
				turn_y -= 0.02
		
		

		if obj['turn_dir'] != old_dir or obj['climb'] != old_climb:		#if turning direction have changed 
			obj['timer'] = 0						#reset the timer
		
		#check if trigger object is on, then apply speed				
		if trigger.hitObject != None and stop == False:# and obj['my'] < 0.004:
			obj['triggered'] = True
			trigger_obj = trigger.hitObject
			#print(trigger_obj.position.z)
			if trigger_obj.position.z <= 0.02:
				
				obj['speed'] = 0.002
			else:
				obj['speed'] = random.uniform(0.002, 0.005)
				if obj['my'] < 0.0004:
					obj['my'] = 0.0004
			#obj['my'] = 0.1
			
			#trigger_dist = trigger_obj.getDistanceTo(obj)
			#trigger_speed = (trigger.distance - trigger_dist)/20
			#if 0 < trigger_speed > obj['speed']:
			#	obj['my'] = trigger_speed
			#	obj['speed'] = trigger_speed
				
			
		#elif trigger.hitObject == None and obj['triggered'] == True:		
		#	obj['speed'] = 0.002

		#slow player obj['speed'] if not in direction to target   <--- cancelled, slowing down also when climbing
		#target_dist = obj.getDistanceTo(target)
		#if target_dist <= 1 and obj['my'] > 0:
			#print(obj, 'near')
		#	if obj['speed'] != 0.0005 and vec[2].y < 0:
				obj['speed'] = 0.002
				
			#	 obj['speed'] =  obj['speed']*vec[2].y
		#	elif obj['speed'] != 0.001 and 0 < vec[2].y < 0.5:
				obj['speed'] = 0.002

		#	elif obj['speed'] != 0.002 and 0.5 < vec[2].y < 0.7:
		#		obj['speed'] = 0.002

			
		if target_dist > 0.5 and obj['my'] > 0 and vec[2].y < 0.5 and ['turn_dir'] == 0:
			obj['turn_dir'] = choosedirection(chkright, chkleft, obj['turn_dir'], vec)	
		
		#Disable gravity when climbing position	
		if ray_ground.hitObject != None:
			if rot_x > 0.2 or rot_x < -0.2 or rot_y < -0.2 or rot_y > 0.2:
			# and obj['climb'] == 0:	
				motion.force = [0, 0, 0.6]
				#if rot_y < -0.2 or rot_y > 0.2 and obj['my'] > 0:
				#	obj['speed'] += 0.002

			#elif ray_ground.hitObject == None:
			#	motion.force = [0, 0, 0]
		else:
			motion.force = [0, 0, 0]
			#if flipped then rotate back
			if rot_y < -0.3:
				turn_y +=0.1
			if rot_y > 0.3:
				turn_y -=0.1
		
		#if reached final target then stop

		#if target == path[len(path)-1] and target_dist <= 0.07:
		#	stop = True
		#	slowlimit = 0
			#print ('stop', obj, target, path[len(path)-1])
		#Apply speed or stop

		if stop == True and obj['my'] >= slowlimit:
			
			obj['my'] = slowtostop(obj['my'], slowlimit)
			#print('slowlimit', obj['my'], slowlimit, obj)
		elif stop == False:
			obj['my'] = accelerate(obj['my'], obj['speed'])

		#Apply Turning	
		if obj['turn_dir'] == 1: 			#turn left
			if obj['turn_Z'] < turnlimit:	
				obj['turn_Z'] += turnaccel
			else:
				obj['turn_Z'] = turnlimit

			if obj['timer'] > 3:
				obj['turn_dir'] = 0
		#	print('Turn left')	
		elif obj['turn_dir'] == 2: 			#turn right
			if obj['turn_Z'] > -turnlimit:	
				obj['turn_Z'] -= turnaccel
			else:
				obj['turn_Z'] = -turnlimit
			
			if obj['timer'] > 3:
				obj['turn_dir'] = 0
		#	print('Turn right')
		elif obj['turn_dir'] == 0 and enemy == None:	#slowdown turning until stop turning
			if obj['turn_Z'] > turnaccel:			
				obj['turn_Z'] -= turnaccel
			elif obj['turn_Z'] < -turnaccel:
				obj['turn_Z'] += turnaccel
			else:
				obj['turn_Z'] = 0
		#print(obj['climb'])

		#apply climbing		
		if obj['climb'] == 1:		#climb up
			#attach.damp = 40
			#attach.rotDamp = 30
			#attach.time = 15
			if obj['turn_X'] < turnlimit:	
				obj['turn_X'] += turnaccel
			else:
				obj['turn_X'] = turnlimit
			if obj['timer'] < 0.2:
				cont.deactivate(attach)
			#else:
			#	cont.activate(attach)
			obj['turn_dir'] = 0

		elif obj['climb'] == 2: 	#climb down
			#attach.damp = 40
			#attach.rotDamp = 30
			#attach.time = 15
			if obj['turn_X'] > -turnlimit:	
				obj['turn_X'] -= turnaccel
				#cont.deactivate(attach)
			else:
				obj['turn_X'] = -turnlimit
				#cont.deactivate(attach)
			if obj['timer'] < 0.1:
				cont.deactivate(attach)
			#else:
			#	cont.activate(attach)
			obj['turn_dir'] = 0	
			
		else:
			#attach.damp = 20
			#attach.rotDamp = 10
			#attach.time = 10
			if obj['turn_X'] > turnaccel:			
				obj['turn_X'] -= turnaccel
			elif obj['turn_X'] < -turnaccel:
				obj['turn_X'] += turnaccel
			else:
				obj['turn_X'] = 0
				cont.activate(attach)
	
		
		
		#obj['point'] = point
  			

		#Activate track to actuator when possible

		if obj['turn_dir'] == 0 and obj['my'] >= 0.0005 and obj['timer'] > 0.15 and obj['climb'] == 0 and rad_near.hitObject == None:
			if 0.5 > rot_x > -0.5 and -0.2 < rot_y < 0.2:
				cont.activate(track_to)
			#	print('activated', obj, obj['my'])
			else:
				cont.deactivate(track_to)	
		elif chkright == 1 or chkleft == 1 or ray_wall.hitObject != None or obj['my'] == 0 or rot_y < -0.2 or rot_y > 0.2:
			cont.deactivate(track_to)
		#	print('deactivated')	
		else:
			cont.deactivate(track_to)
			#print('deactivated')
		if chkright == 1 or chkleft == 1 or ray_wall.hitObject != None or obj['my'] == 0:
			cont.deactivate(track_to)
		#	print('deactivated')

		#if ray_ground.hitObject == None:
		#		motion.force = [0, 0, 0]
		
		#print (motion.force)
		motion.dRot = [obj['turn_X'], turn_y, obj['turn_Z']]
		motion.dLoc = [0, obj['my'], 0]
		cont.activate(motion)	
	
	Update()
